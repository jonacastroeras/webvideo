
<html>
<head><title>TrueMag - Release Log</title>
</head>
<body>
<h1><a href="http://themeforest.net/item/true-mag-wordpress-theme-for-video-and-magazine/6755267">TrueMag - Release Log </a></h1>
<h3><a href="http://themeforest.net/user/cactusthemes">CactusThemes</a></h3>
<ul>
<li><span>True Mag 4.2.19 - 2019.04.16</span><br/>
includes WP Bakery Page Builder 5.6; Revolution Slider 5.4.8.1; Visual Composer 5.7; TrueMag-Movie 3.4.5.2; Cactus-Badges 1.1;
<ul>
	<li><span class="fixed">#Fix</span> Fix mobile menu swipe action issue</li>
	<li><span class="fixed">#Fix</span> Fix series, badge in edit sidebar</li>
	<li><span class="fixed">#Fix</span> Fix VC icon</li>
	<li><span class="fixed">#Fix</span> Fix Meta box</li>
</ul>
</li>
<li><span>True Mag 4.2.18 - 2018.12.13</span><br/>
<ul>
	<li><span class="new">#Update</span> Compatible with WooCommerce Template</li>
	<li><span class="fixed">#Fix</span> Fix Social Icon</li>
	<li><span class="fixed">#Fix</span> Fix https link for share button on hosting use ssl</li>
</ul>
</li>
<li><span>True Mag 4.2.17 - 2018.12.12</span><br/>
includes WP Bakery Page Builder 5.6; Revolution Slider 5.4.8.1; TrueMag-Playlist 1.1.3.3; Cactus Channel 1.0.3.3;
<ul>
	<li><span class="new">#Update</span> Compatible with Wordpress 5.0</li>
	<li><span class="fixed">#Fix</span> Fix Option issue</li>
	<li><span class="fixed">#Fix</span> Fix Color picker</li>
</ul>
</li>
<li><span>True Mag 4.2.16 - 2018.10.01</span><br/>
includes WP Bakery Page Builder 5.5.4
<ul>
	<li><span class="new">#Update</span> Font-Awasome to 5.3.1</li>
	<li><span class="fixed">#Fix</span> Fix Main menu Dropdown overflow</li>
	<li><span class="fixed">#Fix</span> Fix Youtube Video start time warning and support time format</li>
</ul>
</li>
<li><span>True Mag 4.2.15 - 2018.04.27</span><br/>
includes WP Bakery Page Builder 5.4.7; TrueMag-Shortcode 3.3.4.2; Advance Search Form 1.4.8.3
<ul>
	<li><span class="new">#Add</span> Bulk Assign Channel feature</li>
	<li><span class="fixed">#Fix</span> (self-hosted) Video Player displays improperly on mobile when using inbox layout mode</li>
	<li><span class="fixed">#Fix</span> cannot link to other video page on mobile when using Classly Slider layout for video series</li>
	<li><span class="fixed">#Fix</span> (self-hosted) Video Player displays improperly on mobile when using inbox layout mode</li>
	<li><span class="fixed">#Fix</span> auto-play setting for video file</li>
	<li><span class="fixed">#Fix</span> (Advance Search Form) items in search suggestion list do not link to posts</li>
</ul>
</li>
<li><span>True Mag 4.2.14 - 2018.01.31</span><br/>
includes TrueMag-SampleData 1.1; Revolution Slider 5.4.6.6
<ul>
	<li><span class="improved">#Update</span> support WooCommerce 3.3</li>
</ul>
</li>
<li><span>True Mag 4.2.13 - 2018.01.04</span><br/>
includes TrueMag-Playlist 1.1.3.2; Cactus Channel 1.0.3.2; TrueMag-Rating 3.3.2.2; TrueMag-Child-Theme 1.2.1
<ul>
	<li><span class="improved">#Update</span> use Child Theme to bypass Visual Composer Auto-Update</li>
	<li><span class="fixed">#Fix</span> Playlist and Channel select in admin does not work if WooCommerce is not installed</li>
	<li><span class="fixed">#Fix</span> Order by View in archives page does not work properly</li>
	<li><span class="fixed">#Fix</span> CSS issues</li>
</ul>
</li>
<li><span>True Mag 4.2.12 - 2017.11.27</span><br/>
includes TrueMag-Shortcodes 3.3.4.1; TrueMag-Playlist 1.1.3.1; Cactus Channel 1.0.3.1; Visual Composer 5.4.5; Revolution Slider 5.4.6.2
<ul>
	<li><span class="improved">#Update</span> support WooCommerce 3.2.5</li>
	<li><span class="improved">#Update</span> show Video Badges in Channel and Playlist page</li>
	<li><span class="fixed">#Fix</span> minus button in Cart page doesn't work</li>
	<li><span class="fixed">#Fix</span> Product Gallery lightbox doesn't work</li>
</ul>
</li>
<li><span>True Mag 4.2.11 - 2017.08.17</span><br/>
includes TrueMag-Movie 3.4.5.1; TrueMag-Shortcodes 3.3.4; TrueMag-Rating 3.3.2; Revolution Slider 5.4.5.2; Visual Composer 5.2.1
<ul>
	<li>
		<span class="improved">#Update</span> add option to link to Single Video instead of sliding video in Playlist and Series Slider
		</li>
		<li><span class="improved">#Update</span> support WooCommerce 3.1.2</li>
		<li><span class="improved">#Update</span> Theme Options latest version</li>
		<li><span class="fixed">#Fix</span> CSS issues with Facebook Video, BuddyPress Group page, Edit Ad screen</li>
		<li><span class="fixed">#Fix</span> BuddyPress Avatar is not used for User Avatar</li>
		<li><span class="fixed">#Fix</span> make sure submitted post has author</li>
		<li><span class="fixed">#Fix</span> conflict between True Mag Movie plugin and JetPack</li>
		<li><span class="fixed">#Fix</span> YouTube Video has error when URL is short-type and Force Using Embed Code is NO</li>
		<li><span class="fixed">#Fix</span> warning in PHP 7</li>
</ul>
</li>
<li><span>True Mag 4.2.10 - 2017.05.19<br/>
include TrueMag-Movie 3.4.5; TrueMag-Shortcodes 3.3.3; TrueMag-Playlist 1.1.3; Cactus-Channel 1.0.3; Video Ads 3.7; Visual Composer 5.1.1; Revolution Slider 5.4.3.1; TrueMag-sampledata-plugin 1.0
	<ul>
		<li><span class="improved">#Update</span> a better Import Sample Data feature with TrueMag-Sample-Data plugin</li>
		<li><span class="improved">#Update</span> support Youtube URL with Start At parameter, and make Start At option work with Video Ads</li>		
		<li><span class="improved">#Update</span> support Video Ads on mobile</li>		
		<li><span class="improved">#Update</span> move Channels-related features from TrueMag Playlist plugin to Cactus Channel plugin</li>
		<li><span class="improved">#Update</span> make compatible with PHP 7</li>
		<li><span class="fixed">#Fix</span> conflict with Give Donation plugin</li>
		<li><span class="fixed">#Fix</span> auto-scroll issue with playing video of Classy Slider</li>		
		<li><span class="fixed">#Fix</span> TM-Popular Video widget does not generate link when using Most Liked condition</li>
		<li><span class="fixed">#Fix</span> Number of More Videos does not work correctly</li>
		<li><span class="fixed">#Fix</span> messy layout of TM Recent Comments when there isn't an avatar</li>
		<li><span class="fixed">#Fix</span> setting Single Post > Replay does not work correctly</li>		
	</ul>
</li>
<li><span>True Mag 4.2.9.9 - 2017.03.29<br/>
include TrueMag-Movie 3.4.4.5; TrueMag-Shortcodes 3.3.2; Visual Composer 5.1
	<ul>
		<li><span class="fixed">#Fix</span> Sidebar setting of Videos Listing page template and add Page Heading in this page</li>
		<li><span class="fixed">#Fix</span> CSS issues of WPML Language Switcher in menu</li>
		<li><span class="fixed">#Fix</span> Cannot play short YouTube Video URL if "Force Using Embed Code" is not turned off</li>
		<li><span class="improved">#Update</span> Responsive layout of Cart page</li>
		<li><span class="improved">#Update</span> TM Related Posts/Videos widget to have option "Related By"</li>
		<li><span class="new">#Add</span> [classy] shortcode and option to use Classy Slider for posts which belong to a series. Just a beta feature</li>
	</ul>
</li>
<li><span>True Mag 4.2.9.8 - 2017.01.20<br/>
include TrueMag-Movie 3.4.4.4
<ul>
    <li>#Fix: Short YouTube URL issue with Force Using JW Player option and Cactus Ads</li>
    <li>#Fix: Quick View now supports cross-domain video (ie. https URL of YouTube or Vimeo)</li>
    <li>#Fix: TouchSwipe feature of Classy Slider 3 doesn't work properly on mobile</li>
</ul>
</li>
<li><span>True Mag 4.2.9.7 - 2017.01.13<br/>
<ul>
    <li>#Fix: Pagination bug with Top 10 plugin</li>
    <li>#Fix: Excluded Posts issue with Top 10 plugin</li>
    <li>#Fix: Item icon does not appear correctly in Custom Menu widget in footer</li>
    <li>#Fix: incorrect playlist thumbnail in Channel when ajax-loading</li>
    <li>#Fix: Mega Menu - Columns Layout is not 100% width</li>
</ul>
</li>
<li><span>True Mag 4.2.9.6 - 2017.01.05<br/>
include TrueMag-Movie 3.4.4.3; TrueMag-Shortcodes 3.3.1.4; Video Ads Management 3.6.2.7
<ul>
    <li>#Fix: Google Structured Data of inbox layout posts</li>
    <li>#Fix: audio posts does not display thumbnail in Search Results</li>
    <li>#Fix: sidebar settings in Blog and Video Listing page template</li>
    <li>#Fix: always auto-next if video has ads</li>
    <li>#Fix: warning, notice message, CSS issues</li>
    <li>#Update: revolution slider 5.3.1.5</li>
</ul>
<li><span>True Mag 4.2.9.5 - 2016.12.24<br/>
<ul>
    <li>#Fix: responsive issue with HTML5 Native Video Player</li>
    <li>#Fix: FV FlowPlayer doesn't play in Header on mobile devices</li>
    <li>#Fix: GravityForms Submission Form doesn't fetch data</li>
    <li>#Fix: missing post title in Preview Mode of Mega Menu</li>
    <li>#Fix: JW Player 7 doesn't work</li>
    <li>#Fix: cross-sell products doesn't appear in cart</li>
</ul>
</li>
<li>True Mag 4.2.9.4 - 2016.12.06<br/>
<ul>
    <li>#Fix: Front-end Post Submission with Contact Form 7 doesn't work</li>
</ul>
</li>
<li>True Mag 4.2.9.3 - 2016.12.01<br/>
includes TrueMag-Movie 3.4.4.2; TrueMag-Shortcode 3.3.1.3; Video-Ads 3.6.2.4; Advance Search Form 1.4.8.2; Visual Composer 5.0.1; 
    <ul>
        <li>#Fix: compatible with Top 10 plugin</li>
        <li>#Fix: Count param of SCB shortcode doesn't work with Modified condition</li>
        <li>#Update: support GravityForms for Video Submission feature</li>
        <li>#Update: Advance Search Form to include Tags in the search suggestion results</li>
    </ul>
</li>
<li>True Mag 4.2.9.2 - 2016.11.12<br/>
includes TrueMag-Movie 3.4.4.1; Visual Composer 5.0;
    <ul>
        <li>#Fix: style of Ajax loaded posts in Search Results</li>
        <li>#Add: option to autosynchronize views from network</li>
        <li>#Update: Visual Composer 5.0</li>
    </ul>
</li>
<li>True Mag 4.2.9.1 - 2016.11.07<br/>
<ul>
    <li>#Fix: MegaMenu disappears</li>
</ul>
    
</li>
<li>True Mag 4.2.9 - 2016.11.01<br/>
includes TrueMag-Movie 3.4.4; Revolution Slider 5.2.6;  Cactus-Badges 1.0 plugin
<ul>
    <li>#Fix: sidebar setting of Single Product WooCommerce</li>
    <li>#Update: remove JS Color plugin, use default Color Picker component of WordPress</li>
    <li>#Update: support short YouTube URL youtu.be</li>
    <li>#Update: support Video File, Video Code and Video Thumbnail in the upload form</li>
    <li>#Add: Cactus Badges plugin</li>
    <li>#Add: Series Listing page template (in TrueMag-Movie plugin)</li>
</ul>
</li>
<li>True Mag 4.2.8.8 - 2016.09.22<br/>
includes TrueMag-Shortcodes 3.3.1.2; TrueMag-Movie 3.4.3.4; TrueMag-Playlist 1.1.2.3; Cactus BAW Optimizer 1.0
<ul>
    <li>#Add: Cactus BAW Optimizer plugin to delete old data from BAW plugin and convert into Top 10 plugin-compatible</li>
    <li>#Update: support Top 10 plugin (to replace BAW plugin)</li>
    <li>#Update: support using Google Drive URL in Video File</li>
</ul>
</li>
<li>True Mag 4.2.8.7 - 2016.09.17<br/>
includes TrueMag-Shortcodes 3.3.1.1; Visual Composer 4.12.1<br/>
<ul>
    <li>#Fix: cannot click on Vimeo videom when having Ads</li>
    <li>#Update: Visual Composer 4.12.1</li>
    <li>#Update: responsive thumbnails, increase image quality on mobiles</li>
</ul>
</li>
<li>True Mag 4.2.8.6 - 2016.09.08<br/>
includes Visual Composer 4.12.1
<ul>
    <li>#Fix: VC Carousel shortcode, Metro Carousel shortcode in RTL mode</li>
    <li>#Fix: BreadCrumb generates error when posts do not belong to any categories</li>
    <li>#Update: add param to add link in Member Shortcode</li>
    <li>#Update: sub-menu of the last item in boxed layout falls to left side</li>
    <li>#Update: switch Previous and Next button</li>
</ul>
</li>
<li>True Mag 4.2.8.5 - 2016.08.10<br/>
<ul>
    <li>#Fix: Mega Menu - does not first load items when there are 2 Preview Mode items</li>
    <li>#Fix: video auto plays in playlist</li>
    <li>#Fix: English spelling</li>
</ul>
</li>
<li>True Mag 4.2.8.4 - 2016.08.10<br>
includes Video Ads 3.6.2.5
<ul>
    <li>#Fix: Video Ads fatal error</li>
</ul>
</li>
<li>True Mag 4.2.8.4 - 20116.08.09<br/>
includes Video Ads 3.6.2.4
<ul>
    <li>#Fix: WooCommerce Cross-Sells not showing in Cart</li>
    <li>#Fix: scrolling issues with Visual Composer Tabs</li>
    <li>#Fix: some text error</li>
    <li>#Update: update Optiona Page libs in Video Ads plugin</li>
</ul>
</li>
<li>True Mag 4.2.8.3 - 2016.07.04<br/>
includes TrueMag-Movie 3.4.3.3; TrueMag-Child-Theme-Poster 1.3
<ul>
	<li>#Fix: error when BAW plugin is not installed</li>
	<li>#Update: support WooCommerce 2.6</li>
	<li>#Update: Child Theme Poster-Size bugs fixed and uses poster size for thumbnails in loop</li>
</ul>
</li>
<li>True Mag 4.2.8.2 - 2016.06.23
	<ul>
		<li>#Fix: dropdown menu in RTL mode</li>
		<li>#Fix: child theme poster size</li>
		<li>#Fix: Video Ads doesn't work with direct link from Amazon S3</li>
		<li>#Fix: multi-links video doesn't work with Vimeo and DailyMotion</li>
	</ul>
</li>
<li>True Mag 4.2.8.1 - 2016.06.10
	<ul>
		<li>#Fix: bulk activate recommended plugin (update TGM Plugin activation)</li>
		<li>#Fix: CSS issues</li>
		<li>#Update: remove JWPlayer 6 from recommended plugins</li>
		<li>#Update: Visual Composer 4.12</li>
	</ul>
</li>
<li>TrueMag 4.2.8 - 2016.05.25
	<ul>
		<li>#Fix: Share Facebook to link back to website</li>
		<li>#Fix: JWPlayer 6 on mobile issue</li>
		<li>#Fix: JWPlayer 7 logo issue</li>
		<li>#Fix: Most Viewed Posts widget doesn't work</li>
		<li>#Fix: CSS in menu management in admin</li>
		<li>#Fix: HTTPs issue with playlist</li>
		<li>#Update: Revolution Slider 5.2.5.2</li>
		<li>#Update: Use Embed Code in multi-links for video posts</li>
	</ul>
</li>
<li>TrueMag 4.2.7 - 2016.04.27<br/>
include Visual Composer 4.11.2.1; Revolution Slider 5.2.5; Cactus-Video 1.1.2.1
	<ul> <li>#Fix: changing sidebar position for single playlist doesn't work</li></ul>
</li>
<li>TrueMag 4.2.7 - 2016.04.14<br/>
include Visual Composer 4.11.2; Revolution Slider 5.2.4.1; Video-Ads 3.6.2.2
<ul>
	<li>#Update: WordPress 4.5 compatibility</li>
	<li>#Fix: Video Ads issues</li>
	<li>#Fix: VideoJS doesn't work </li>
	<li>#Add: option to include og:video:secure_url</li>
</ul>
</li>
<li>TrueMag 4.2.6 - 2016.03.31<br/>
include Visual Composer 4.11.1; Revolution Slider 5.2.3; TrueMag-Movie 3.4.3.1; Advance-Search-Form 1.4.8.1
<ul>
	<li>#Fix: some PHP warning messages</li>
	<li>#Fix: Playlist page breaks when using Boxed layout</li>
	<li>#Fix: search results page when using child theme</li>
	<li>#Fix: cannot play video in multi-link when using Boxed layout</li>
	<li>#Update: support latest WooCommerce 2.5.5</li>
</ul>
</li>
<li>TrueMag 4.2.5 - 2016.03.14<br/>
include Visual Composer 4.11
<ul>
<li>#Update: support WooCommerce 2.5.5</li>
<li>#Update: support Meipai & Vid.me videos</li>
<li>#Fix: bug when sorting tags by like</li>
<li>#Fix: bug of View Count number in Smart Content Box</li>
</ul>
</li>
<li>TrueMag 4.2.4 - 2016.02.26<br/>
includes Visual Composer 4.10; Cactus Video (TrueMag Playlist) 1.1.2; Video Ads 3.6.2.1
<ul>
<li>#Fix: order by Likes in Series page</li>
<li>#Fix: 2 Most Viewed Posts widgets</li>
<li>#Fix: Quick View doesn't work in Big Detail 1 Column layout</li>
<li>#Fix: XSS exploit in search</li>
<li>#Fix: unable to hide Related Videos in Video List</li>
<li>#Fix: show View Count in Blog listing</li>
<li>#Fix: Reply button click in comment form</li>
<li>#Fix: Cactus Ads message hides other admin messages</li>
<li>#Update: add Edit link in single Post/Page for Admin</li>
<li>#Update: support Youku Video</li>
</ul>
</li>
<li>TrueMag 4.2.3 - 2016.02.04<br/>
includes Visual Composer 4.9.2; Revolution Slider 5.1.6; Video Ads 3.6.2; Cactus Video (TrueMag 

PlayList) 1.1.1; Cactus Channel 1.0.2
<ul>
<li>#Fix: theme breaks when freshly installed</li>
<li>#Fix: Option Header - Category of Front Page queries incorrect posts of category</li>
<li>#Fix: Video Ads admin cannot open popup to upload image. Random Ads doesn't work</li>
<li>#Update: Support FlowPlayer 6: https://wordpress.org/plugins/flowplayer5/</li>
<li>#Fix: FV FlowPlayer conflicts</li>
<li>#Update: Visual Composer 4.9.2</li>
<li>#Update: Revolution Slider 5.1.6</li>
</ul>
</li>
<li>TrueMag 4.2.2 - 2016.01.26<br/>
<ul>
	<li>#Fix: BreadCrumb text in Video Listing page</li>
	<li>#Fix: Carousel does not display items in child categories</li>
	<li>#Fix: post navigation in Tag page</li>
	<li>#Update: child theme 1.2</li>
</ul>
</li>
<li>TrueMag 4.2.1 - 2015.12.31<br/>
includes Visual Composer 4.9.1
<ul><li>#Fix: headline is missing is Top Navigation is sticky</li>
<li>#Fix: Channel Listing consumes too many resources</li>
<li>#Fix: Search Icon is missing in Navigation Styel 4</li>
<li>#Fix: first video in multi-link list cannot be played when using embed code</li>
<li>#Update: improve child theme to not use @import in style.css</li>
</ul>
</li>
<li>TrueMag 4.2 - 2015.11.27<br/>
includes Revolution Slider 5.1.1
	<ul>
	<li>#Update: Support JWPlayer 7 for WordPress plugin</li>
	<li>#Update: support BuddyPress 2.4.0</li>
	<li>#Update: True Mag child theme to remove @import css</li>
	<li>#Fix: minor CSS issues</li>
	</ul>
</li>
<li>TrueMag 4.1.2 - 2015.11.14<br/>
include TrueMag-Shortcodes 3.3; Cactus Video (TrueMag-PlayList) 1.1; Advance Search Form 1.4.8
<ul>
	<li>#Fix: breadcrumbs in Video Series does not display correctly</li>
	<li>#Fix: Load More feature does not work in Channel and Playlist</li>
	<li>#Fix: notice messages in WordPress 4.3.1</li>
</ul>
</li>
<li>TrueMag 4.1.1 - 2015.10.30<br/>
includes Video-Ads 3.6.1; Visual Composer 4.8.1
<ul>
	<li>#Fix: "Search" text translation</li>
	<li>#Fix: Image Size in Blog page</li>
	<li>#Fix: CSS issues of fixed background</li>
	<li>#Update: remove single page of video ads</li>
</ul>
</li>
<li>TrueMag 4.1 - 2015.10.21<br>
includes TrueMag-PlayList 1.0.2; Video-Ads 3.6; Revolution Slider 5.1<br> 
<ul>
	<li>#Fix: css for IE</li>
	<li>#Fix: Category Carousel shortcode to order by most liked videos</li>
	<li>#Fix: self-hosted video player issue in small screens</li>
	<li>#Fix: embed code - video player on Iphone 6+</li>
	<li>#Fix: some notice warnings</li>
	<li>#Fix: update language file</li>
	<li>#Update: Video Ads 3.6 to support self-hosted videos</li>
	<li>#Update: show Channel &amp; Playlist column in admin for posts</li>
	<li>#Update: Main Navigation Layout - Centered Logo layout</li>
</ul>
</li>
<li>TrueMag 4.0.9 - 2015.10.06<br/>
	<ul>
		<li>#Fix: display Standard Post in Blog Listing</li>
		<li>#Update: Visual Composer 4.7.4</li>
	</ul>
</li>
<li>TrueMag 4.0.8 - 2015.09.28<br/>
includes updates: Video Ads 3.5
<ul>
<li>#Fix: Contact Form 7 doesn't work if there are more than 2 forms on page</li>
<li>#Fix: Vimeo Video cannot play on https</li>
<li>#Fix: YouTube Video cannot play on iPad</li>
<li>#Update: Video Ads 3.5 which contains "random ads display" feature during play</li>
</ul>
</li>
<li>TrueMag 4.0.7 - 2015.09.23<br/>
includes updates: TrueMag-Movie 3.4.2; TrueMag-Shortcode 3.2.7; TrueMag-Rating 3.3; Revolution Slider 5.0.8.5; Visual Composer 4.7.2
<ul>
	<li>#Fix: fixed menu with hidden headline</li>
	<li>#Fix: unable to display thumbnail of a Facebook Video Post in listing page</li>
	<li>#Fix: Testimonials shortcode do not slide</li>
	<li>#Update: Font Awesome 4.4</li>
	<li>#Add: option to specify short name for videos in a series</li>
</ul>
</li>
<li>TrueMag 4.0.6 - 2015.08.27<br/>
includes updates: TrueMag-Movie 3.4.1; Revolution Slider 5.0.4.1
<ul>
	<li>#Fix: RTL issues</li>
	<li>#Update: support WP 4.3</li>
	<li>#Update: remove auto update feature, use of Envato WordPress Toolkit plugin instead</li>
	<li>#Update: remove favicon feature, use of default WP 4.3 feature</li>
</ul>
</li>
<li>TrueMag 4.0.5 - 2015.07.23<br/>
includes updates: Video Ads 3.4.2; Cactus-Video 4.0.5
<ul>
	<li>#Fix: rich snippet for full-width video player single post</li>
	<li>#Fix: setting full-width for channel listing page doesn't work</li>
	<li>#Fix: search results page layout if post thumbnails are missing</li>
	<li>#Fix: Image Ads css</li>
	<li>#Update: support https</li>
	<li>#Update: Support WooCommerce 2.4.1</li>
	<li>#Update: Visual Composer 4.6.2</li>
	<li>#Update: Revolution Slider 5.0.4</li>
</ul>
</li>
<li>TrueMag 4.0.4 - 2015<br/>
includes updates: Video Ads 3.4.1.4; truemag-shortcodes 3.2.6
<ul>
	<li>#Fix: Widget Logic integration bug</li>
	<li>#Fix: default value issue of Smart Content Box in VC 4.6.1</li>
	<li>#Fix: Vimeo Video Ads link does not work</li>
	<li>#Fix: smooth scroll in iOS 8.4+</li>
</ul>
</li>
<li>TrueMag 4.0.3 - 2015 July 17th<br/>
includes updates: Video Ads 3.4.1.3; cactus-channel 1.0.1; cactus-playlist 1.0.1;
<ul>
	<li>#Fix: language translation</li>
	<li>#Fix: default video quality when using Video Ads</li>
	<li>#Update: add social accounts for Channels</li>
	<li>#Update: Visual Composer 4.6.1</li>
</ul>
</li>
<li>TrueMag 4.0.2 - 2015 July 9th<br/>
include updates: Video Ads 3.4.1.2; TrueMag-Shortcodes 3.2.5
<ul>
	<li>#Fix: special character issue in different languages of Video Sitemap feature</li>
	<li>#Fix: Video Ads hide part of player</li>
	<li>#Fix: RTL issues</li>
	<li>#Fix: post sharing issues with special characters in title</li>
	<li>#Update: order items in playlist by Published DateTime</li>
	<li>#Update: Visual Composer 4.6</li>
	<li>#Update: include WTI-Like Post plugin</li>
	<li>#Add: Theme Options > Social Accounts > Custom Social Accounts</li>
</ul>
</li>
<li>TrueMag 4.0.1 - 2015 June 30th<br/>
includes updates: Video Ads 3.4.1.1; TrueMag Movie 3.4
<ul>
	<li>#Fix: bug in Video Sitemap template</li>
	<li>#Fix: RTL and Custom Color issues for Cactus Channel</li>
	<li>#Fix: images are blur in some places</li>
	<li>#Fix: conflict between Video Ads and Cactus Channel, Cactus PlayList plugins</li>
	<li>#Update: hover to stop Testimonial carousel</li>
	<li>#Update: option to change long Movie Series list into Select-Box </li>
</ul>
</li>
<li>TrueMag 4.0 - 2015 - June 25th<br/>
include updates: Video Ads 3.4.1; Cactus Channel 1.0; TrueMag Playlist 1.0
	<ul>
		<li>#Update: display logic for menu items on mobile devices</li>
		<li>#Fix: minor CSS issue</li>
		<li>#Update: add VK Social Icon</li>
		<li>#Update: User Submit Form now supports Category Radio Boxes</li>
		<li>#Update: CSS for YouTube player fullwidth</li>
		<li>#Add: Cactus Channel plugin</li>
		<li>#Add: TrueMag Playlist plugin</li>
		<li>#Add: able to bulk set Video Ads ID to all videos</li>
	</ul>
</li>
<li>TrueMag 3.4.1 - 2015 - June 17th
	<ul>
		<li>#Fix: duplicated Sub Total table in WooCommerce cart</li>
		<li>#Update: PrettyPho lib 3.1.6</li>
		<li>#Update: Visual Composer plugin 4.5.3</li>
		<li>#Update: WooCommerce 2.3.8 template files</li>	
		<li>#Add: option to set default YouTube Video Playback Quality</li>
	</ul>
</li>
<li>TrueMag 3.4 - 2015 - Jun 6th<br/>
	<ul>
		<li>#Fix: Video Sitemap is broken if title has some special characters</li>
		<li>#Fix: Quick View is broken</li>
		<li>#Fix: minor CSS issues</li>
		<li>#Fix: Incorrect image thumbnail of article when sharing on Facebook</li>
		<li>#Update: Improve True Mag performance grade (need to run Regenerate Thumbnail again)</li>
		<li>#Update: able to limit size of Video Sitemap page</li>
		<li>#Add: Video Caption for JWPlayer</li>
	</ul>
</li>
<li>TrueMag 3.3 - 2015 - May 9th<br/>
includes updates: <b>Visual Composer 4.5.1</b>, <b>Revolution Slider 

4.6.93</b>, <b>TrueMag Movie 3.3</b>
<ul>
<li>#Fix: Link parameter in Title of widgets does not work</li>
<li>#Fix: meta description of author page to use author biography</li>
<li>#Fix: hide video toolbar of YouTube player in inbox layout when not hovering</li>
<li>#Fix: order by Like in category page does not work</li>
<li>#Fix: SCB shortcode orders by Item IDs</li>
<li>#Fix: Header sliders order by Item IDs</li>
<li>#Update: use history.pushState in Ajax pagination to better support SEO</li>
<li>#Update: support WooCommerce Ajax pagination</li>
<li>#Fix: YouTube API 3.0 compatible</li>
<li>#Update: Visual Composer 4.5.1</li>
<li>#Update: Revolution Slider 4.6.93</li>
</ul>
</li>
<li>TrueMag 3.2.5 - 2015 - April 22nd<br/>
includes updates: <b>Video Ads 3.2.5</b>, <b>Advance Search Form 1.4.7</b>, <b>TrueMag Movie 3.2.5</b> and <b>Revolution Slider 4.6.9</b>
	<ul>
		<li>#Fix: JW Player 2.1.12 compatible</li>
		<li>#Fix: active video in More Videos of Single Inbox</li>

		<li>#Fix: CSS for TM-Recent Comments widget</li>
		<li>#Fix: header Classy Sliders are broken when using Ajax pagination</li>
		<li>#Fix: fatal error if WP PageNavi plugin is missing</li>
		<li>#Fix: fatal error if WTI Like Post plugin is missing</li>
		<li>#Fix: using deprecated function get_current_theme</li>
		<li>#Fix: Video Ads plays audio only when main video is fullscreen (now 

disabled)</li>

		<li>#Update: support WP YouTube Video Post plugin</li>
		<li>#Update: Support Facebook Embedded Videos</li>
		<li>#Update: TGM Activation class 2.4.1</li>
		<li>#Update: OptionTree 2.5.3</li>
		<li>#Update: Revolution Slider 4.6.9</li>
		<li>#Update: fix security vulnerability 

(http://themeforest.net/forums/thread/security-vulnerability-affecting-wordpress-plugins-

and-themes/173011)</li>
		<li>#Add: Video Sitemap export</li>
	</ul>
</li>
<li>TrueMag 3.2.4 - 2015 - April 2nd<br/><br/>
include <b>TrueMag-Shortcode 3.2.4</b>; <b>TrueMag-Movie 3.2.4</b> and <b>Video-Ads 3.2.4</b><br/><br/>
	<ul>
		<li>#Fix: default avatar in comment form for guests</li>
		<li>#Fix: Self-hosted video in Classy Slider</li>
		<li>#Fix: fatal error when using "Next Video by Tag" option in HTTPS websites</li>
		<li>#Fix: missing thumbnail image of gallery post in search results</li>
		<li>#Fix: CSS in RTL mode</li>
		<li>#Update: Video Ads to support inbox video layout</li>
		<li>#Update: support WooCommerce 2.3.7</li>
		<li>#Add: Option to play next videos in series</li>
		<li>#Add: option to add Facebook ID for like button</li>
	</ul>
</li>
<li>TrueMag 3.2.3 - 2015 - March 18th
	<ul>
		<li>#Fix: missing thumnail image for gallery posts in Search Results</li>
		<li>#Fix: Theme Options for custom Search Results page</li>
		<li>#Update: Mobile Detect Library (in both Video Ads plugin and theme) to fix blurring images issue</li>
		<li>#Update: Visual Composer plugin 4.4.3</li>
		<li>#Add: Report Video feature</li>
	</ul>
</li>
<li>TrueMag 3.2.2 - 2015 - March 9th
	<ul>
		<li>#Fix: incorrect hover icon of Smart Content Box</li>
		<li>#Fix: Vimeo Social Icon of member does not appear (truemag-member plugin 3.2.2)</li>
		<li>#Fix: truemag-rating plugin cannot be activated right after installed (truemag-ratign plugin 3.2.2)</li>
		<li>#Fix: Classy Header is broken in RTL mode</li>
		<li>#Fix: option Header - Items IDs does not work</li>
		<li>#Fix: Video Slider does not animate</li>
		<li>#Fix: blurring featured images on latest browsers</li>
		<li>#Update: Video Ads plugin to support new auto-play feature (video-ads plugin 3.2.2)</li>
	</ul>
</li>
<li>TrueMag 3.2.1 - 2015 - March 3rd
	<ul>
		<li>#Fix: conflict with TrueMag-rating plugin</li>
	</ul>
</li>
<li>TrueMag 3.2 - 2015 - February 28th
	<ul>
		<li>#Fix: use Video Code in Blog Listing</li>
		<li>#Fix: CSS issue with fixed menu</li>
		<li>#Fix: PHP warning in header-series.php</li>
		<li>#Fix: missing alt property in Smart Content 

Box's thumbnails</li>
		<li>#Fix: icon on post standard in Smart Content 

Box</li>
		<li>#Fix: missing search button on mobile</li>
		<li>#Fix: CSS issue with list</li>
		<li>#Update: support HTTPs</li>
		<li>#Update: video player responsive</li>
		<li>#Update: translation (need to update all truemag-plugins)</li>
		<li>#Update: add more filter options in Front 

Page template</li>
		<li>#Update: add Time Range options for Header 

and Slider</li>
		<li>#Update: add more options for Auto Play 

feature</li>
		<li>#Update: date_i18n function to display local 

time string</li>
 	</ul>
</li>
<li>TrueMag 3.1.2 - 2015 - February 12th
	<ul><li>#Fix: TrueMag-Rating 2.13; TrueMag-Shortcodes 3.1.2 and Video-Ads 2.4</li></ul>
</li>
<li>TrueMag 3.1.2 - 2015 - February 9th
	<ul>
		<li>#Fix: Sidebar Layout for FrontPage template</li>
		<li>#Fix: warning message in TrueMag-Rating plugin</li>
		<li>#Fix: Headline widget is not running</li>
		<li>#Fix: some minor CSS bugs</li>
		<li>#Update: Smart Content Box to support Date Range query (truemag-shortcodes plugin)</li>
		<li>#Update: "Skip Ads" text option in Video-Ads plugin</li>
		<li>#Update: translation</li>
		<li>#Update: Visual Composer 4.4.2</li>		
	</ul>
</li>
<li>TrueMag 3.1.1 - 2015 - January 22th
	<ul>
		<li>#Fix: some minor CSS bugs</li>
		<li>#Fix: Reddit, VK Sharing buttons does not work</li>
		<li>#Fix: setting right sidebar for header style "Video Slide"</li>
		<li>#Fix: menu in RTL mode</li>
		<li>#Fix: Smart Content Box to query standard post format</li>
		<li>#Fix: [Advance Search Form plugin 1.4.5] fix bug that pages are listed in blog 

page</li>
		<li>#Fix: specify Post IDs for Amazing slider does not work</li>
		<li>#Add: [truemag-movie plugin 3.1.1] Widget "Top Videos by Author"</li>
		<li>#Update: sorting option for Headline widget</li>
		<li>#Update: [truemag-shortcodes 3.1.1] Smart Content Box shortcode to support CSS 

animation</li>
		<li>#Update: Visual Composer 4.4.1</li>
	</ul>
</li>
<li>TrueMag 3.1 - 2015 - January 8th
	<ul>
	<li>#Fix: video.js player bug</li>
	<li>#Fix: change color and background in Classy Slider Header</li>
	<li>#Fix: Amazing Slider css</li>
	<li>#Fix: JWPlayer css</li>
	<li>#Fix: bug with BreadCrumb</li>
	<li>#Update: TrueMag-Child-Theme-Poster-Size</li>
	<li>#Update: Advance Search Form (1.4.3) to fix warning bugs in search page</li>
	<li>#Update: Support Contus Video Player</li>
	<li>#Update: Support Kaltura Video Player</li>
	<li>#Update: change Page Smooth Scroll effect</li>
	</ul>
</li>
<li>TrueMag 3.0.1 - 2014 - December 25th
<ul>
	<li>#Fix: Smart Content Box shortcode to filter Standard Posts</li>
	<li>#Fix: Wistia player plays no sound</li>
	<li>#Fix: some minor CSS</li>
	<li>#Fix: unable to click on logo link</li>
	<li>#Fix: some settings for YouTube player do not work in Classy Slider</li>
	<li>#Update: Visual Composer 4.3.5 to support WordPress 4.1</li>
	<li>#Update: Advance Search Form 1.4.2 to support BBPress</li>
	</ul>
</li>
<li>TrueMag 3.0 - 2014 - December 18th
<ul>
<li>#Fix: CSS for video player in Classy Slider</li>
<li>#Fix: Smart Content Box order by Post Title</li>
<li>#Fix: some minor CSS issues</li>
<li>#Update: Option Tree</li>
<li>#Add: integrated Mega Menu for True Mag (no need extra Mega Menu plugin)</li>
<li>#Add: Movie Series feature (truemag-movie plugin)</li>
<li>#Add: Multi-links for video post feature (truemag-movie plugin)</li>
<li>#Add: option to filter posts by Post Format in Smart Content Box (truemag-

shortcode plugin)</li>
</ul>
</li>
<li>TrueMag 2.18 - 2014 - December 17th
<ul>
<li># Update: Video Ads plugin 2.3 to support HTML Ads</li>
<li># Update: New Social Sharing buttons</li>
</ul>
</li>
<li>TrueMag 2.17.1 - 2014 - December 04th
<ul>
	<li># Fix: player is mis-aligned on Ipad and IE when using "Force Using YouTube Embed Code"</li>
	<li># Fix: CSS bugs in WooCommerce</li>
	<li># Fix: JWPlayer breaks on mobile</li>
	<li># Fix: Video Ads for Vimeo does not work when "Auto Load Next" is off</li>
	<li># Update: sidebars for WooCommerce pages</li>
</ul>
</li>
<li>TrueMag 2.17 - 2014 - December 01st
<ul>
	<li># Add: Support WooCommerce</li>
	<li># Add: Header conditions for Front-page template </li>	
	<li># Add: option to change the direction of auto-load next video</li>
	<li># Fix: JW Player breaks in inbox layout</li>
	<li># Fix: Related Posts by Category generates errors</li>
	<li># Fix: some minor CSS issues</li>
</ul>
</li>
<li>TrueMag 2.16 - 2014 - November 20th
<ul>
	<li># Add: Option to play YouTube inside JWPlayer</li>
	<li># Add: Option to play external video source inside VideoJS player</li>
	<li># Add: Option to control carousel speed</li>
	<li># Add: Conditional Code for video player</li>
	<li># Add: Notification for Submitted Posts</li>	
	<li># Update: Video Ads plugin 2.2</li>
	<li># Update: TrueMag Shortcodes 2.16</li>
</ul>
</li>
<li>TrueMag 2.5 - 2014 - November 14th
<ul>
	<li># Fix: "Auto fetch data" for user submitted posts</li>
	<li># Fix: Show Excerpt property doesn't work in some shortcodes</li>
	<li># Fix: Link to comments section in single posts doesn't work with Disqus</li>
	<li># Update: Smart Content Box to fix layout issues with inappropriate thumbnail size from YouTube</li>
	<li># Add: Option to play YouTube inside JWPlayer</li>
	<li># Add: Option to play external video source inside VideoJS player</li>
	<li># Add: Option to control carousel speed</li>
	<li># Add: Conditional Code for video player</li>
	<li># Add: Notification for Submitted Posts</li>
	<li># Add: Option to choose Related Posts by categories or tags</li>
	<li># Add: Option to sort headlines</li>
</ul>
</li>
<li>TrueMag 2.14.5 - 2014 - November 07th
	<ul>
		<li># Fix: Testimonial fatal error</li>
		<li># Fix: Submit Video form is hidden on FireFox in Single Post</li>
		<li># Update: JetPack compatibility</li>
		<li># Update: Video Ads plugin 2.0.1</li>
		<li># Update: Support WooCommerce (blind release)</li>
		<li># Update: language file</li>
	</ul>
</li>
<li>TrueMag 2.14.4 - 2014 - October 31th
<ul>
<li># Fix: color of icon on off-canvas menu</li>
<li># Update: Video Ads plugin 2.0</li>
<li># Update: TrueMag-shortcodes plugin</li>
</ul>
</li>
<li>TrueMag 2.14.3 - 2014 - October 25th
<ul>
<li># Fix: Amazing Slider autoplay bug</li>
<li># Fix: notice bug in functions.php</li>
<li># Fix: Google WebMaster Structured Data with blog post</li>
<li># Update: support Audio Post Format</li>
<li># Update: support DailyMotion Video API to fetch data</li>
<li># Update: improve Metro Slider UX on mobiles</li>
<li># Update: Count Views stats when viewing video on Quick View popup</li>
</ul>
</li>
<li>TrueMag 2.14.2 - 2014 - September 24th
<ul>
<li># Fix: cannot input category for Video Slider shortcode (TrueMag-shortcodes plugin)</li>
<li># Fix: required fields in Video Submit Form</li>
<li># Fix: hover color of Video Submit Form button</li>
<li># Fix: some minor CSS bugs</li>
<li># Update: Video Ads plugin to work properly on mobile (only Image ads)</li>
</ul>
</li>
<li>TrueMag 2.14.1 - 2014 - September 18th
<ul>
<li># Fix: some bugs with Video Ads plugin</li>
<li># Fix: some CSS issues with navigation</li>
<li># Fix: cannot input categories in Smart Content Box shortcode in Visual Composer</li>
<li># Update: FontAwesome 4.2.0</li>
</ul>
</li>
<li>TrueMag 2.14 - 2014 - September 17th
<ul>
<li># Fix: Reset Password page is redirected to Login Page</li>
<li># Fix: Solid Background Color isn't working</li>
<li># Fix: Tab and Carousel scrolling issue</li>
<li># Update: Banner Image style for category having blog listing</li>
<li># Update: TrueMag shortcode is now separated from Visual Composer plugin</li>
<li># Update: Visual Composer 4.3.4</li>
<li># Add: 2 menu styles</li>
<li># Add: OnePress Social Locker plugin integration</li>
<li># Add: Video Ads plugin</li>
<li># Add: Scroll Effect (Theme Options)</li>
</ul>
</li>
<li>TrueMag 2.13 - 2014 - September 04th
<ul>
<li># Fix: Ajax loading error</li>
<li># Fix: Mobile Detect library conflict</li>
<li># Fix: some minor CSS bugs</li>
<li># Update: add Theme Options to choose action when sharing videos on Facebook</li>
</ul>
</li>
<li>TrueMag 2.12 - 2014 - August 22th
<ul>
<li># Fix: Footer Ad Slot ID does not appear</li>
<li># Fix: error "undefined __toString() function of SimpleXMLElement" in some PHP built</li>
<li># Update: use ColorBox (MIT License) instead of HTML5LightBox</li>
</ul>
</li>
<li>TrueMag 2.11.3 - 2014 - August 12th
<ul>
<li># Fix: some minor errors</li>
<li># Fix: auto-fetch video tags</li>
</ul>
</li>
<li>TrueMag 2.11 - 2014 - July 25th
<ul>
<li># Fix: error in Submit Video feature with Contact Form 7 version 3.9</li>
</ul>
</li>
<li>TrueMag 2.11 - 2014 - July 25th
<ul>
<li># Update: Revolution Slider 4.5.95</li>
<li># Update: support Google Structured Data (Rich Snippets)</li>
<li># Update: support Facebook Open Graph for Video sharing</li>
<li># Update: Font Awesome 4.1.0</li>
<li># Fix: BuddyPress 'view all' activity comments doesn't work</li>
<li># Fix: Prev/Next post navigation doesn't work with qTranslate</li>
</ul>
</li>
<li>TrueMag 2.10 - 2014 - July 7th
<ul>
<li># Update: Revolution Slider 4.5.7</li>
<li># Fix: self-hosted video does not appear on Classy Slider front page</li>
<li># Fix: bug when using multiple Feature Content Box shortcodes in a page</li>
<li># Fix: some minor CSS, JS bugs</li>
<li># Update: getting "more videos" by tags (Theme Options)</li>
</ul>
</li>
<li>TrueMag 2.9 - 2014 - June 14th
<ul>
<li># Update: Revolution Slider 4.5.2</li>
<li># Update: Language file</li>
<li># Fix: Video Player height in mobile</li>
<li># Fix: Date Time in Amazing Slider</li>
<li># Fix: Touch issue of Classy Slider on iOS</li>
<li># Fix: User Submit Video feature - missing video description</li>
<li># Fix: Unable to add Carousel shortcode in Visual Composer</li>
<li># Add: TM Review shortcode button</li>
</ul>
</li>
<li>TrueMag 2.8.2 - 2014 - May 23rd
<ul>
<li># Update: Visual Composer 4.1.3</li>
</ul>
</li>
<li>TrueMag 2.8.1 - 2014 - May 20th
<ul>
<li># Fix: some bugs with Amazing Slider</li>
<li># Add: support social accounts Instagram, Email</li>
</ul>
</li>
<li>TrueMag 2.8 - 2014 - May 16th
<ul>
<li># Add: options to open new tab when clicking on Social Links</li>
<li># Add: New Home Page Header Style - Amazing Slider</li>
<li># Add: options for category page layout (left sidebar, right sidebar, fullwidth)</li>
</ul>
</li>
<li>TrueMag 2.7.3 - 2014 - May 16th
<ul>
<li># Fix: cannot hide author & date info in Boxed-style Single post</li>
<li># Fix: bug with Side Slider Front-page layout if choosing Left Sidebar</li>
<li># Fix: "Sort by" bug in Blog listing page if using language URL</li>
<li># Update: Language file</li>
<li># Add: options to turn on post metadata in Medium Grid layout</li>
</ul>
</li>
<li>TrueMag 2.7.2 - 2014 - May 10th
<ul>
<li># Fix: bug with Auto Update feature</li>
</ul>
</li>
<li>TrueMag 2.7.1 - 2014 - May 09th
<ul>
<li># Fix: Some CSS issues</li>
<li># Fix: Some minor issues</li>
<li># Update: Visual Composer 4.1.2</li>
<li># Update: Revolution Slider 4.3.8</li>
<li># Add: Parameter to hide Quick View popup in Smart Content Box shortcode (TrueMag-Shortcodes plugin)</li>
<li># Add: Set Background for single page</li>
</ul>
</li>
<li>TrueMag 2.7 - 2014 - May 06th
<ul>
<li># Fix: Some CSS issues</li>
<li># Fix: Choosing Full-width for an individual post does not work</li>
<li># Fix: 'Auto-fetch data' feature still works when Video URL is empty</li>
<li># Update: support WordPress 3.9</li>
<li># Add: User Submit Video</li>
<li># Add: 3 more header styles for front-page</li>
<li># Add: Choose background for a single video post</li>
<li># Add: New widget style</li>
<li># Add: Feature Content Box shortcode</li>
<li># Add: Video Carousel shortcode</li>
</ul>
</li>
<li>TrueMag 2.6.2 - 2014 - April 18th
<ul>
<li># Update: Revolution Slider 4.3.5</li>
<li># Update: Visual Composer 4.1</li>
<li># Fix: Fixed menu's width in Boxed layout</li>
<li># Fix: Shortcode buttons in TinyMCE editer WP 3.9</li>
</ul>
</li>
<li>TrueMag 2.6 - 2014 - April 3rd
<ul>
<li># Add: <a href="http://demo.cactusthemes.com/truemag/carousel-slider-2/">New HomePage Header</a></li>
<li># Add: Sticky Header</li>
<li># Add: Lightbox (Quick View) for big carousel in home page</li>
<li># Add: Users able to turn on "Auto Next Video"</li>
<li># Add: Left-Right side Ads, Main content Ads</li>
<li># Add: Auto-fetch YouTube View count</li>
<li># Support: Premium content with <a href="https://premium.wpmudev.org/project/membership/">Membership plugin</a></li>
<li># Update: Support Interactive Videos</li>
<li># Update: Change enqueue uri function to support child theme</li>
<li># Update: Search result page - change players with feature image</li>
<li># Update: Option Tree 2.3.4</li>
<li># Update: Support option to set number of excerpts</li>
<li># Update: Theme Options - Enable/Disable Show More content button in single post</li>
<li># Update: On/off Full-width featured image for standard posts</li>
<li># Fix: Accordion, Toggle, Tour Section, Tab do not work</li>
<li># Fix: activate truemag-rating invalid header error (Plugin Truemag Rating)</li>
<li># Fix: Share this button hide when no social enable</li>
<li># Fix: some other minor issues</li>
</ul>
</li>
<li>TrueMag 2.4.1 - 2014 - March 21st
<ul>
<li># Fix: margin-bottom 35px of Visual Composer row</li>
<li># Fix: some other minor issues</li>
<li># Update: option to limit number of categories in widget Top Categories</li>
<li># Update: support custom avatar plugin</li>
<li># Fix: "unavailable" video when using Embed Code</li>
<li># Fix: Share toolbar is missing in single inbox layout</li>
<li># Update: Revolution Slider 4.2.4</li>
<li># Fix: Off Canvas menu level 3rd & 4th</li>
<li># Update: more YouTube player options</li>
<li># Update: Support Custom Content Type Manager plugin</li>
<li># Update: Multisite tested</li>
<li># Update: Theme Options for Share This Publisher ID</li>
</ul>
</li>
<li>TrueMag 2.4 - 2014 - March 13rd
<ul>
<li># Add: Theme Option to hide search box</li>
<li># Update: Visual Composer 4.0.1 (truemag-shortcodes plugin)</li>
<li># Fix: auto load next video setting does not work</li>
<li># Fix: Auto-Fetch-Data feature does not work on some hosts</li>
<li># Fix: deplicate meta data in smart content box shortcode</li>
</ul>
</li>
<li>TrueMag 2.3 - 2014 - February 28th
<ul>
<li># Add: Boxed Layout</li>
<li># Add: Option to set page background</li>
<li># Add: Option to set body font color</li>
<li># Add: Option to display Feature Image or Video Player for video post in Blog format</li>
<li># Add: Option to add Post View Count toolbar in single standard post page</li>
<li># Fix: recurring refresh on some servers</li>
<li># Fix: Disqus Comment integration</li>
<li># Fix: cannot select category in shortcode Smart Content Box (plugin TrueMag Shortcode)</li>
</ul>
</li>
<li>TrueMag 2.2 - 2014 February 22nd
<ul>
<li># theme - Add: User Playlist</li>
<li># theme - Add: support Wistia Player</li>
<li># theme - Update: no need to specify page template for Login page</li>
<li># theme - Update: vertical center for navigation menu</li>
<li># theme - Fix: main navigation level 3rd & 4th</li>
<li># theme - Fix: cannot click on Search Button if using default wordpress search box</li>
<li># theme - Fix: quick view error if there are special characters in content</li>
<li># theme - Fix: options to show/hide info in post listing page</li>
<li># theme - Improve: loading experience</li>
<li># ct-member plugin - Add: ID column for member post</li>
<li># truemag-shortcodes plugin - update Visual Composer 3.7.4</li>
<li># truemag-shortcodes plugin - change icons for shortcode</li>
<li># truemag-shortcodes plugin - Add: Compare Table shortcode</li>
<li># truemag-rating plugin - Fix: turn off FontAwesome setting does not work</li>
</ul>
</li>

<li>TrueMag 2.1 - 2014 February 15th
<ul>
<li> Add support BBPress</li>
<li> Add support FlowPlayer and VideoJS HTML5 layer</li>
<li> Fix some CSS issues</li>
<li> Fix "cannot find sample data" error</li>
</ul>

<li>TrueMag 2.0 - 2014 February 11th
<ul>
<li>Add: BuddyPress Support</li>
<li>Fix: CSS issues</li>
<li>Fix: DailyMotion video player overflow issue</li>
<li>Add: TrueMag Shortcode plugin - shortcode Heading</li>
<li>Update: TrueMag Movie plugin</li>
<li>Add: Tool to convert data from deTube </li>
</ul>
</li>
<li>TrueMag 1.0 - 2014 February 2nd - First Release </li>
</ul>
</body>
</html>
