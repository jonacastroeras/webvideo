<?php

require_once 'page-metadata.php';
require_once 'post-metadata.php';
